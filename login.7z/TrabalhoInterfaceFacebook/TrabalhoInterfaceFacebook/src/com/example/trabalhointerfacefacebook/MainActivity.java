package com.example.trabalhointerfacefacebook;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    
    public void changescene(View p)
    {
    	Intent home = new Intent(this, HomeActivity.class);
    	
    	final EditText email = (EditText) findViewById(R.id.email);
        final EditText senha = (EditText) findViewById(R.id.senha);
    	
    	String emailcerto = "milho";
		String senhacerta = "cozido";
		String stremail = email.getText().toString();
		String strsenha = senha.getText().toString();
	
		if (stremail.equals(emailcerto) && strsenha.equals(senhacerta))
		{
			Toast.makeText(MainActivity.this, "Login com sucesso", Toast.LENGTH_SHORT).show();
	    	startActivity(home);
		}else{
			Toast.makeText(MainActivity.this, "Erro! login ou senha incorretos", Toast.LENGTH_SHORT).show();
		}
    }
    
    private EditText findViewId(int edittext1) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
